import Image from "next/image";
import { useState, useEffect, useCallback, useMemo } from "react";

export default function Avatar({
  src,
  alt = "User avatar",
  width = 64,
  height = 64,
  className = "",
  ...props
}) {
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  // Reset states when src changes
  useEffect(() => {
    if (src) {
      setHasError(false);
      setIsLoading(true);
    } else {
      setHasError(false);
      setIsLoading(false);
    }
  }, [src]);
  
  const handleError = useCallback(() => {
    setHasError(true);
    setIsLoading(false);
  }, []);
  
  const handleLoad = useCallback(() => {
    setIsLoading(false);
  }, []);
  
  // Generate fallback letter from alt text
  const fallbackLetter = useMemo(() => {
    return alt.charAt(0).toUpperCase();
  }, [alt]);
  
  // Base container classes
  const containerClasses = useMemo(() => {
    return `relative rounded-full overflow-hidden w-8 h-8 sm:w-12 sm:h-12 md:w-12 md:h-12 bg-gray-200 flex items-center justify-center ${className}`;
  }, [className]);

  // If no src provided, show letter avatar immediately
  if (!src) {
    return (
      <div className={containerClasses}>
        <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
          <span className="text-white font-bold text-lg">
            {fallbackLetter}
          </span>
        </div>
      </div>
    );
  }

  // If image failed to load, show letter avatar
  if (hasError) {
    return (
      <div className={containerClasses}>
        <div className="w-full h-full bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
          <span className="text-white font-bold text-lg">
            {fallbackLetter}
          </span>
        </div>
      </div>
    );
  }

  // Check if it's an external URL
  const isExternalUrl = src.startsWith("http://") || src.startsWith("https://");

  return (
    <div className={containerClasses}>
      {/* Loading skeleton */}
      {isLoading && (
        <div className="absolute inset-0 bg-gray-200 animate-pulse rounded-full" />
      )}
      
      {/* Next.js Image */}
      <Image
        src={src}
        alt={alt}
        width={width}
        height={height}
        className={`w-full h-full object-cover transition-opacity duration-200 ${
          isLoading ? 'opacity-0' : 'opacity-100'
        }`}
        unoptimized={isExternalUrl || src.startsWith("data:")}
        onError={handleError}
        onLoad={handleLoad}
        priority={false}
        {...props}
      />
    </div>
  );
}

// Simplified debug component
export function AvatarDebug({ src }) {
  return (
    <div className="p-4 border rounded bg-gray-50">
      <h3 className="font-bold mb-2">Avatar Debug Info:</h3>
      <div className="space-y-1 text-sm">
        <div>Provided src: <code>{src || 'null'}</code></div>
        
        {/* Test renders */}
        <div className="mt-4">
          <p className="font-semibold">Test renders:</p>
          <div className="flex gap-4 mt-2">
            <div>
              <p className="text-xs mb-1">With URL:</p>
              <Avatar src={src} width={64} height={64} alt="Test User" />
            </div>
            
            <div>
              <p className="text-xs mb-1">Without URL:</p>
              <Avatar src={null} width={64} height={64} alt="Test User" />
            </div>
            
            <div>
              <p className="text-xs mb-1">Invalid URL:</p>
              <Avatar src="invalid-url.jpg" width={64} height={64} alt="Test User" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}